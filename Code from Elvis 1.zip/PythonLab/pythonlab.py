#! /usr/bin/python

def past_tense(noun):
    if noun == "run":        
        return "ran"
    elif noun == "buy":
        return "bought"
    elif noun == "play":
       return "played"
    elif noun == "plan":
        return "planned"
    elif noun == "shop":
        return "shopped"
    elif noun[-1] == "e":        
        return noun + "d"       
    elif noun[-1] == "c":        
        return noun + "ked"    
    elif noun[-1:] == "y":        
        return noun[0:-1] + "ied"    
    else:        
        return noun + "ed" 

print(past_tense("jump"))
print(past_tense("laugh"))
print(past_tense("run"))
print(past_tense("plan"))
print(past_tense("shop"))
print(past_tense("buy"))
print(past_tense("follow"))
print(past_tense("agree"))
print(past_tense("change"))
print(past_tense("decide"))
print(past_tense("copy"))
print(past_tense("study"))
print(past_tense("panic"))
print(past_tense("attack"))
print(past_tense("play"))
print(past_tense("mimic"))
