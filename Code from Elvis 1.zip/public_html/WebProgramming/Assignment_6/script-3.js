//lets console log numbers 1
console.log('numbers 1 - 10')
console.log(1);  //these are statements finish with delimitor
console.log(2); 
console.log(3); 
console.log(4);
console.log(5);
console.log(6);
console.log(7);
console.log(8);
console.log(9);
console.log(10);

//JavaScript is iterative and executes line by line

//Part 2 - alternatie LOGGING
console.log('every second number from 2 to 10')
console.log(3,5,7,9);
console.log('every second number from 10 to 2')
console.log(9,7,5,3);

console.log('1 to 10 and whether they are even or odd');

console.log(1 + 'odd');
console.log(2 + 'even');
console.log(3 + 'odd');
console.log(4 + 'even');
console.log(5 + 'odd');
console.log(6 + 'even');
console.log(7 + 'odd');
console.log(8 + 'even');
console.log(9 + 'odd');
console.log(10 + 'even');

let text = prompt();

let i;
for(i = 0; i<= text.length-1; i++ )
{
    console.log(text[i]);
}

for(i=text.length-1; i>=0; i--)
{
    console.log(text[i]);
}

