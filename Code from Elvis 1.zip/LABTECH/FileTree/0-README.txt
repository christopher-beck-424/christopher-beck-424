This is file 0-README.txt.
It was created by Christopher Beck, username 'beckch36'.
It is supposed to be exactly 200 characters long.
Here are extras: 1234578909876543212345678909876543212345678909I3
