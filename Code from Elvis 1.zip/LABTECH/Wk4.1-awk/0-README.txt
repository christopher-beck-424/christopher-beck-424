Summary of Awk

Awk reads each line and automatically breaks it into separate
words along whitespace (default) or some other character (with
the -F flag).

Words are in $1, $2, $3 . . . for however many words there are.
$0 is the whole line.

Awk also sets two other variables
    NR for 'Number of Record'
    NF for 'Number of Fields'

$NF is the last word on the line, $(NF-1) is the second-to-last,
and so on.  (Don't get NF and $NF mixed up!)


For each line, awk runs all its instructions, which have this form:

   condition { command }

The default condition is 'true', and the default command is 'print $0'.

There are four kinds conditions we care about:

    Relational:

       print second field if first is greater than 5 :   $1 > 5 { print $2 }

    Patterns (must be in slashes):

       print entire line if it starts with 'k':  /^k/
       (note no command here)

    Before reading any data:

       set up initial values:  BEGIN { sum = 0 }

    After processing all lines:

       print summary report:   END { print sum }


Commands can include if and while statements, and many other programming
structures you already know, including function calls.

