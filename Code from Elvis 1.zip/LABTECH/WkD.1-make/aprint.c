#include <stdio.h>

void aprint()
{
  printf("The first letter is A.\n");
}
