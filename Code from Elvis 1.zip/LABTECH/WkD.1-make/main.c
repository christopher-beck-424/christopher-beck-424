/* main routine of abprint program
 */

int main()
{
  int aprint(void);
  int bprint(void);

  aprint();
  bprint();

  return 0;
}
