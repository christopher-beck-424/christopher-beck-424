#include <stdio.h>

void bprint()
{
  printf("The second letter is B.\n");
}
