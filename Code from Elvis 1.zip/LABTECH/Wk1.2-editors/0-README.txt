FILES AND EDITING:

A file is an ordered stream of bytes.  The operating system kernel has
no internal structure for any file.  The bytes are binary numbers, in
groups of eight.

For a text file, such as this one, the binary encodes characters from
the ASCII character set, and an application that understands ASCII
characters can handle that file.

For example, 'hello.txt' in this folder is just a plain text file.
It can be seen with 'cat', or with 'more', or editted using any of
the standard text editors, such as pico, nono, vim, or emacs.

    % cat hello.txt
    Hello, this is file 'hello.txt'.
    %

But what's stored on the hard drive is actually just binary numbers,
which you can see with the 'xxd' command, using the '-b' flag:

    % xxd -b hello.txt
    00000000: 01001000 01100101 01101100 01101100 01101111 00101100  Hello,
    00000006: 00100000 01110100 01101000 01101001 01110011 00100000   this
    0000000c: 01101001 01110011 00100000 01100110 01101001 01101100  is fil
    00000012: 01100101 00100000 00100111 01101000 01100101 01101100  e 'hel
    00000018: 01101100 01101111 00101110 01110100 01111000 01110100  lo.txt
    0000001e: 00100111 00101110 00001010                             '..
    %

(Note that in the right column, xxd prints a '.' for the newline at the
end of the file, which is the last character.  In binary, it's '00001010'.)

Most people don't work well with raw binary, and prefer hexadecimal.  The
'od' progam can show both ASCII characters and hex values, with the right
flags:

    % od -ctx1 hello.txt
    0000000   H   e   l   l   o   ,       t   h   i   s       i   s       f
             48  65  6c  6c  6f  2c  20  74  68  69  73  20  69  73  20  66
    0000020   i   l   e       '   h   e   l   l   o   .   t   x   t   '   .
             69  6c  65  20  27  68  65  6c  6c  6f  2e  74  78  74  27  2e
    0000040  \n
             0a
    0000041
    %

If you look up those values (see ascii(7) in the online manual), you can
see that '20' is the hex value for a space, and so on.


It's important to understand that the kernel doesn't care what a file
is.  To the operating system, it's just a bunch of bits that get saved
in the right order, and nothing else.  Whatever meaning the file has will
depend on the application that opens it.  If you open a file with an app
that doesn't know what to do, it may get confused.


For example, 'bluedot.png' is a 1x1 PNG image of a single blue pixel.
(It's on the web at http://elvis.rowan.edu/~kilroy/class/lab_tech/PNGs/ .)

A web browser can open it, or a program such as paintbrush or preview,
but if you run 'more' or 'cat' on it, they'll just get confused.

    % cat bluedot.png
    �PNG

    IDATx�c``����w
                  �IEND�B`�%

(Note that the '%' on the end is the shell prompt, not part of the file.)

Those programs are designed to manage ASCII text, not images.  If you
try to edit it, you'll similarly get gibberish.


Programs such as xxd(1) or od(1) are safe to run on any kind of file,
but if a file is long (remember 'ls -l' will tell you big a file is),
you might want to pipe the output to more:

    % od -ctx1 bluedot.png | more
    0000000 211   P   N   G  \r  \n 032  \n  \0  \0  \0  \r   I   H   D   R
             89  50  4e  47  0d  0a  1a  0a  00  00  00  0d  49  48  44  52
    0000020  \0  \0  \0 001  \0  \0  \0 001  \b 006  \0  \0  \0 037 025 304
             00  00  00  01  00  00  00  01  08  06  00  00  00  1f  15  c4
    0000040 211  \0  \0  \0  \r   I   D   A   T   x 234   c   `   ` 370 377
             89  00  00  00  0d  49  44  41  54  78  9c  63  60  60  f8  ff
    0000060 037  \0 003 002 001 377 346   w  \v 256  \0  \0  \0  \0   I   E
             1f  00  03  02  01  ff  e6  77  0b  ae  00  00  00  00  49  45
    0000100   N   D 256   B   ` 202
             4e  44  ae  42  60  82
    0000106
    %


The file(1) program can tell you what a file is, or at least make a
good guess.  It's also safe to run on any kind of file.

    % file hello.txt
    hello.txt: ASCII text
    % file bluedot.png
    bluedot.png: PNG image data, 1 x 1, 8-bit/color RGBA, non-interlaced
    %




Elvis has some simple editors, such as pico and nano, but they are too
simple to really get serious work done.

Most users find they prefer either vim or emacs.

Elvis has a built-in tutorial for vim called 'vimtutor'.  It works
best if you run it in a 25-line window.  Vim has two modes, 'command'
and 'insert'.  Insert mode is for typing text; command mode is for
issuing commands.  To get out of insert mode, hit the ESCAPE key.
There is a printable vim reference card here:
   https://michaelgoerz.net/refcards/vimqrc.pdf


Emacs is always in insert mode; if you type regular characters, they
get added to the file where the cursor is.  To use commands, Emacs
relies on the control keys.  Emacs has many thousands of builtin
commands, and includes a Lisp interpreter, so you can write your own
commands if you want.
There is a printable Emacs reference card here:
   https://www.gnu.org/software/emacs/refcards/pdf/refcard.pdf


