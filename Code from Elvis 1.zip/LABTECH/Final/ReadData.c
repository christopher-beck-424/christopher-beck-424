#include <stdio.h>
#include <strings.h>

typedef struct {
	char inits[5];
	char num;
} info;

int main(int argc, char *argv[])
{
	info data;
	FILE *datastream;

	datastream = fopen(argv[1], "r");

	while ( fread(&data, sizeof(info), 1, datastream) == 1 ) {
		printf("%d - %s\n", data.num, data.inits);
	}

	fclose(datastream);

	return 0;
}
