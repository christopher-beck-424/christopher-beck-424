#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int val = 0;
	int len = strlen(argv[1]);

	for(int i=0;i < len; i++) {
		val <<= 1;
		if ( argv[1][i] == '1' )
			val |= 1;
	}
	
	printf("%d\n", val);
}
