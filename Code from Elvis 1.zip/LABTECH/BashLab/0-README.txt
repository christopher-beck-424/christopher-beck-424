BASH SHELL SCRIPT LAB EXERCISES

There are four shell scripts in this folder.  None is complete.
Working with your group, finish them all.  Be sure to put everyone's
name in the comment block at the top.


1) simpledata

This script should print out something that looks like this:

>   Current time: Wed Mar 10 09:35:25 AM EST 2021
>  Your username: edisona2
> Your full name: Annie Edison
>
> This script by: A Nadir, B Perry, and J Winger

Obviously the output will be different each run, and you should
put your names at the bottom.  (In alphabetical order by last name,
with Oxford Comma.)

For full names, you will want to start with this command:
   getent passwd $USER
and then use some filters.




2) addstudent

This script takes two arguments, a username and a file.  If the file
does not exist, is not a regular file, or cannot be read and written,
the script should give an error and quit.

The username should be added to the file, in alphabetical order among
the other names.

For example, the file 'students.txt' in this folder has these names:

    barnes5
    bennett4
    changb66
    edison13
    hawthor9
    lambert2
    nadira11
    perryb2
    winger23

If the command 'addstudent kimann81 students.txt' is run, the file
should then be:

    barnes5
    bennett4
    changb66
    edison13
    hawthor9
    kimann81
    lambert2
    nadira11
    perryb2
    winger23

NOTE: it might be best to create the new file with a different name.
Then do some simple tests, such as running 'wc -l' to see if the new
file is exactly one line longer than the old file.
Then rename the old file (adding '-backup' or something), and move
the newly-created file to the name given on the command line.





3) findempties

This script takes an optional argument, which is the name of a folder.
(If no folder is named, use the current working directory.)

It should print out a list of all regular files in the directory which
are empty.

(In this folder, 'EmptyFile' is the only one.)



4) checkfiles

This script takes two arguments, a text file and a folder.

It should report an error if the file does not exist, is not a regular
file, or is not readable.

It should report an error if the folder does not exist, is not a folder,
or is not readable.

The text file will have one filename per line.

The script should go through the filenames (remember a for-in loop
can get its list of words from any source, such as a using a command
substition to cat out a file), and print out names of files which are
on the list but not in the folder.

The command './checkfiles DirList.txt DirTest' should print:

   Checking folder DirTest against file list DirList.txt
   Missing files:
      c
      
   

