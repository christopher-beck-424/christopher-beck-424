This folder just has some sample files for students to work with.

Files and their contents:

   0-README.txt           - this file
   EmptyDir               - a folder with no files in it
   .dotfile               - filename starts with "."
   file.with.lots.of.dots - just what it says
   hello.c                - simple C program
   TrekCrew.csv           - some _Star Trek_ crewmembers done as
                            comma-separated values (CSV)


Things you can do to see filenames:

   ls       : list files, but not ".", "..", or ".dotfile".
   ls -a    : list ALL files, including ones whose names start with '.'
   ls -l    : long-form listing, with dates and size and permissions
   ls -la   : long-form listing of ALL files
   ls -al   :     same as above
   ls -a -l :     same as above
   ls -l -a :     same as above
   ls -ld   : show information about this directory, instead of the files
   ls -ld / : show information about root directory, not this one
   echo *   : echos back filenames, but not the dotfiles.


Note the difference:

   ls -l EmptyDir   - shows no files, because none in the folder
   ls -ld EmptyDir  - shows information about the folder

   ls -la EmptyDir  - shows information about '.' and '..'
   ls -lad EmptyDir - shows information about 'EmptyDir'
                      (compare with information about '.' above)


How to find out where you are:

   pwd : Print Working Directory


Things you can do to see what's in files:

   cat FILENAME : prints contents of FILENAME on screen


Things you can do with the C program:

   cc hello.c : will compile "hello" into "a.out"
   ./a.out    : run "a.out" program in this directory (after compiling it)

