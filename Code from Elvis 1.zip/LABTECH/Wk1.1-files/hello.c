/* hello.c - say hello
 *
 * D Provine, 10 Jan 2019
 */

#include <stdio.h>

int main()
{
    printf("Hello, Students!\n");

    return 0;
}
