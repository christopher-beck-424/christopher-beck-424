/* sum2.c -- add up all numbers from 1-N
 *
 * D Provine, 24 June 2020
 *
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    if ( argc != 2 ) {
        fprintf(stderr, "Usage: %s integer\n", argv[0]);
        exit(1);
    }

    int num = atoi(argv[1]);
    int sum = 0;
    int i   = num;

    while ( i >= 0 ) {
        sum += i;
        i--;
    }

    printf("%d\n", sum);
}
