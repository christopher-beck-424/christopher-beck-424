#include <stdio.h>
 
int main()
{
	printf("\033[7mReversed\033[m Normal\n");

	printf("\033[7m \033[m \033[7m \033[mx\n");

 
	return 0;
}

