/* findblank.c - find blank characters
 *
 * D Provine, 26 Nov 2019
 */

#include <stdio.h>
#include "Chars/All_Chars.h"

int main()
{
    int thechar;
    int line;
    int notblank = 0;

    // start at 0x21; 0x20 is literally the blank character
    for (thechar = 0x21; thechar < 0x7E; thechar++) {
        notblank = 0;
        for (line = 0; line < 10; line++) {
            if ( (*glyph[thechar-0x20])[line] != 0 ) {
                notblank = 1;
            }
        }
        if ( notblank == 0 ) {
            printf("%c ", thechar);
        }
    }
    printf("\n");
}
