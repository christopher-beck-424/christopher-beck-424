/* All_Chars.h - include all the characters
 *
 * D Provine, 20 Mar 2012
 */

typedef unsigned char byte;

#include "Char_20.h"
#include "Char_21.h"
#include "Char_22.h"
#include "Char_23.h"
#include "Char_24.h"
#include "Char_25.h"
#include "Char_26.h"
#include "Char_27.h"
#include "Char_28.h"
#include "Char_29.h"
#include "Char_2A.h"
#include "Char_2B.h"
#include "Char_2C.h"
#include "Char_2D.h"
#include "Char_2E.h"
#include "Char_2F.h"
#include "Char_30.h"
#include "Char_31.h"
#include "Char_32.h"
#include "Char_33.h"
#include "Char_34.h"
#include "Char_35.h"
#include "Char_36.h"
#include "Char_37.h"
#include "Char_38.h"
#include "Char_39.h"
#include "Char_3A.h"
#include "Char_3B.h"
#include "Char_3C.h"
#include "Char_3D.h"
#include "Char_3E.h"
#include "Char_3F.h"
#include "Char_40.h"
#include "Char_41.h"
#include "Char_42.h"
#include "Char_43.h"
#include "Char_44.h"
#include "Char_45.h"
#include "Char_46.h"
#include "Char_47.h"
#include "Char_48.h"
#include "Char_49.h"
#include "Char_4A.h"
#include "Char_4B.h"
#include "Char_4C.h"
#include "Char_4D.h"
#include "Char_4E.h"
#include "Char_4F.h"
#include "Char_50.h"
#include "Char_51.h"
#include "Char_52.h"
#include "Char_53.h"
#include "Char_54.h"
#include "Char_55.h"
#include "Char_56.h"
#include "Char_57.h"
#include "Char_58.h"
#include "Char_59.h"
#include "Char_5A.h"
#include "Char_5B.h"
#include "Char_5C.h"
#include "Char_5D.h"
#include "Char_5E.h"
#include "Char_5F.h"
#include "Char_60.h"
#include "Char_61.h"
#include "Char_62.h"
#include "Char_63.h"
#include "Char_64.h"
#include "Char_65.h"
#include "Char_66.h"
#include "Char_67.h"
#include "Char_68.h"
#include "Char_69.h"
#include "Char_6A.h"
#include "Char_6B.h"
#include "Char_6C.h"
#include "Char_6D.h"
#include "Char_6E.h"
#include "Char_6F.h"
#include "Char_70.h"
#include "Char_71.h"
#include "Char_72.h"
#include "Char_73.h"
#include "Char_74.h"
#include "Char_75.h"
#include "Char_76.h"
#include "Char_77.h"
#include "Char_78.h"
#include "Char_79.h"
#include "Char_7A.h"
#include "Char_7B.h"
#include "Char_7C.h"
#include "Char_7D.h"
#include "Char_7E.h"

const byte (* const glyph[])[10] = {
    &Char_20,
    &Char_21,
    &Char_22,
    &Char_23,
    &Char_24,
    &Char_25,
    &Char_26,
    &Char_27,
    &Char_28,
    &Char_29,
    &Char_2A,
    &Char_2B,
    &Char_2C,
    &Char_2D,
    &Char_2E,
    &Char_2F,
    &Char_30,
    &Char_31,
    &Char_32,
    &Char_33,
    &Char_34,
    &Char_35,
    &Char_36,
    &Char_37,
    &Char_38,
    &Char_39,
    &Char_3A,
    &Char_3B,
    &Char_3C,
    &Char_3D,
    &Char_3E,
    &Char_3F,
    &Char_40,
    &Char_41,
    &Char_42,
    &Char_43,
    &Char_44,
    &Char_45,
    &Char_46,
    &Char_47,
    &Char_48,
    &Char_49,
    &Char_4A,
    &Char_4B,
    &Char_4C,
    &Char_4D,
    &Char_4E,
    &Char_4F,
    &Char_50,
    &Char_51,
    &Char_52,
    &Char_53,
    &Char_54,
    &Char_55,
    &Char_56,
    &Char_57,
    &Char_58,
    &Char_59,
    &Char_5A,
    &Char_5B,
    &Char_5C,
    &Char_5D,
    &Char_5E,
    &Char_5F,
    &Char_60,
    &Char_61,
    &Char_62,
    &Char_63,
    &Char_64,
    &Char_65,
    &Char_66,
    &Char_67,
    &Char_68,
    &Char_69,
    &Char_6A,
    &Char_6B,
    &Char_6C,
    &Char_6D,
    &Char_6E,
    &Char_6F,
    &Char_70,
    &Char_71,
    &Char_72,
    &Char_73,
    &Char_74,
    &Char_75,
    &Char_76,
    &Char_77,
    &Char_78,
    &Char_79,
    &Char_7A,
    &Char_7B,
    &Char_7C,
    &Char_7D,
    &Char_7E
};
