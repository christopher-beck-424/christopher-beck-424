/* Char_55.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 */

const byte Char_55[10] = {
    0x00,     // ........
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x24,     // ..x..x..
    0x24,     // ..x..x..
    0x28,     // ...xx...
    0x00      // ........
};

