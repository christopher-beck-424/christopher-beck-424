/* Char_56.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 */

const byte Char_56[10] = {
    0x00,     // ........
    0x81,     // x......x
    0x81,     // x......x
    0x81,     // x......x
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x24,     // ..x..x..
    0x18,     // ...xx...
    0x00,     // ........
    0x00      // ........
};

