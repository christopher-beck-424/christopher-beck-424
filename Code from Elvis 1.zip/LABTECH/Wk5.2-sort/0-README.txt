This folder contains files needed for the "sort" lab.

 0-README.txt - this file

     arya.zip - Arya Stark's files, as a zipped folder.
                To open, run "unzip arya.zip".
                You will then have a folder named "arya" with files in it.

  HPbdays.txt - List of birthdays of Harry Potter characters.

      tgp.txt - List of people from _The Good Place_.


