Software Testing Exercise

The specification for this program was as follows:

    Read in numbers from the keyboard, one per line, until it gets a zero.
    Then print out, in this order:
        the number of values entered,
        the sum of all values,
        the largest number,
        the smallest number,
        the average of all the numbers.

    Do not count the zero. (So, if you read in 4, 8, and 0, the average
    is 6, because only two numbers were entered before the before the 0.)

Two data sets were provided, with sample input and output.

This file contains a compiled program, 'stats', which I wrote to solve
this problem.

If you run the program on the data sets, like this:

    ./stats < data1_in.txt

and then look at the sample output:

    more data1_out.txt

You'll see that the program works correctly.


HOWEVER:

This program may have some bugs.  As you do not have the source code
to examine, you will need to run tests to find any bugs which are there.

Your assignment is to work with your group and see if you can find ways
that the program's operation does not match the spec above.  To do this,
you'll need to test different sets of input data, and see if any cause
incorrect operation or output.


Note that you can test the program from the command line by just typing
numbers in, as follows (assuming your shell prompt is just '%'):

    % ./stats      <= running the program; remember '.' is current folder
    2                <= user typing input starts here
    4
    6
    12
    -9
    0              <= sentinel value ends input
    # items: 5       <= program output starts here
    Sum:     15
    Maximum: 12
    Minimum: -9
    Mean:    3
    %             <= program has exited and shell has given next prompt

