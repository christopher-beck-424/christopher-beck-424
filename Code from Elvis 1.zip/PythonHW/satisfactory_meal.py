#! /usr/bin/python

def clara_ok(dish):
    if not dish:
        return False
    elif dish[1] == 1:
        return True
    else:
        return False

def isaiah_ok(dish):
    if not dish:
        return False
    elif dish[2] == 0:
        return True
    else:
        return False

def jasmine_ok(dish):
    if not dish:
        return False
    elif dish[3] == 0:
        return True
    else:
        return False

def rafael_ok(dish):
    if not dish:
        return False
    elif (dish[3] == 0) and (dish[4] == 1):
        return True
    else:
        return False

def clara_count(meal):
    if not meal:
        return 0
    count = 0;
    for dish in meal:
        if clara_ok(dish):
            count = count + 1
    return count

def isaiah_count(meal):
    if not meal:
        return 0
    count = 0;
    for dish in meal:
        if isaiah_ok(dish):
            count = count + 1
    return count

def jasmine_count(meal):
    if not meal:
        return 0
    count = 0;
    for dish in meal:
        if jasmine_ok(dish):
            count = count + 1
    return count

def rafael_count(meal):
    if not meal:
        return 0
    count = 0;
    for dish in meal:
        if rafael_ok(dish):
            count = count + 1
    return count

def edible(meal):
    count = False;
    if not meal:
        return True
    for dish in meal:
        if((clara_ok(dish) == True) or (isaiah_ok(dish) == True) or (jasmine_ok(dish) == True) or (rafael_ok(dish) == True)):
            count = True
        else:
            return False
    
    return count
    

def satisfactory_meal(meal):
    if not meal:
        return False
    if((edible(meal) == True) and (clara_count(meal) > 2) and (isaiah_count(meal) > 2) and (jasmine_count(meal) > 2) and (rafael_count(meal) > 2)):
                return True
    else:
        return False

meal2 = [9,0,1,1,1]
meal = [[1, 1, 0, 0, 0], [3, 1, 0, 0, 1], [5, 0, 0, 0, 1], [7, 1, 0, 0, 1], [9, 0, 1, 1, 1]] 

print(satisfactory_meal(meal))
