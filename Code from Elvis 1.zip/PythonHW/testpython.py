#! /usr/bin/python

from satisfactory_meal import *

def testg1():
	print(satisfactory_meal([
     [8,  0, 0, 0, 1],
     [9,  1, 1, 0, 1],
     [23, 1, 0, 0, 1],
     [2,  1, 0, 1, 0],
     [6,  0, 0, 1, 1] ]))

def testg2():			# Everybody can eat everything
	print(satisfactory_meal([
     [1, 1, 0, 0, 1],
     [2, 1, 0, 0, 1],
     [3, 1, 0, 0, 1] ]))

def testg3():
	print(satisfactory_meal([
     [1, 1, 1, 1, 0],
     [3, 1, 1, 1, 0],
     [5, 0, 0, 0, 1],
     [7, 1, 0, 0, 0],
     [9, 1, 0, 0, 1],
     [8, 1, 0, 0, 1],
     [6, 1, 0, 1, 0],
     [4, 1, 1, 0, 0] ]))

def testb1():		# Fails: Clara, Rafael
	print(satisfactory_meal([
     [4,  1, 0, 0, 0],
     [7,  0, 1, 0, 1],
     [90, 0, 0, 0, 0],
     [3,  0, 0, 1, 1] ]))

def testb2():		# Fails: Nobody is happy
	print(satisfactory_meal([]))

def testb3():		# Fails: Clara
	print(satisfactory_meal([
    [1, 0, 0, 0, 1],
    [3, 1, 0, 0, 1],
    [5, 1, 0, 0, 1],
    [7, 0, 0, 0, 1],
    [9, 0, 0, 1, 1] ]))

def testb4():		# Fails: Isaiah
	print(satisfactory_meal([
     [1, 1, 1, 1, 1],
     [3, 1, 0, 0, 1],
     [5, 1, 1, 0, 1],
     [7, 0, 0, 1, 1],
     [9, 0, 1, 0, 1] ]))

def testb5():			# Fails: Jasmine & Rafael
	print(satisfactory_meal([
     [1, 1, 0, 0, 0],
     [3, 1, 0, 1, 0],
     [5, 0, 0, 0, 1],
     [7, 0, 0, 1, 0],
     [9, 1, 0, 1, 1] ]))

def testb6():			# Fails: Rafael
	print(satisfactory_meal([
     [1, 1, 0, 0, 0],
     [3, 1, 0, 0, 0],
     [5, 0, 0, 0, 1],
     [7, 0, 0, 1, 0],
     [9, 1, 0, 0, 0] ]))

def testb7():			# Fails: Nobody can eat dish 3
	print(satisfactory_meal([
     [1, 1, 0, 0, 1],
     [3, 0, 1, 1, 1],
     [5, 0, 0, 0, 1],
     [7, 1, 0, 1, 0],
     [9, 1, 0, 0, 1] ]))

def testb8():			# Fails: Nobody can eat dish 9
	print(satisfactory_meal([
     [1, 1, 0, 0, 0],
     [3, 1, 0, 0, 1],
     [5, 0, 0, 0, 1],
     [7, 1, 0, 0, 1],
     [9, 0, 1, 1, 1] ]))

print("Test g1 - should be True:  ")
testg1()
print()
print("Test g2 - should be True:  ")
testg2()
print()
print("Test g3 - should be True:  ")
testg3()
print()
print("Test b1 - should be False:  ")
testb1()
print()
print("Test b2 - should be False:  ")
testb2()
print()
print("Test b3 - should be False:  ")
testb3()
print()
print("Test b4 - should be False:  ")
testb4()
print()
print("Test b5 - should be False:  ")
testb5()
print()
print("Test b6 - should be False:  ")
testb6()
print()
print("Test b7 - should be False:  ")
testb7()
print()
print("Test b8 - should be False:  ")
testb8()
print()

