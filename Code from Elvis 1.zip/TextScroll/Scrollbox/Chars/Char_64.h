/* Char_64.h - LOWER_CASE_D Character
 *
 * D Provine, 20 Mar 2012
 * S Lekko, 21 Aprl 2021
 */

const byte Char_64[10] = {
    0x00,     // ........
    0x02,     // ......x.
    0x02,     // ......x.
    0x02,     // ......x.
    0x1A,     // ...xx.x.
    0x26,     // ..x..xx.
    0x26,     // ..x..xx.
    0x1A,     // ...xx.x.
    0x00,     // ........
    0x00      // ........
};

