/* Char_70.h - NAME_OF_CHARACTER Character
 *
 * V Corradetti, 22 April 2021
 */

const byte Char_70[10] = {
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
    0x3c,     // ..xxxx..
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x7c,     // .xxxxx..
    0x40,     // .x......
    0x40      // .x......
};

