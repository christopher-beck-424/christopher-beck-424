/* Char_35.h - 5 Character
 *
 * D Provine, 20 Mar 2012
 * B Raley,   21 Apr 2021
 */

const byte Char_35[10] = {
    0x00,     // ........
    0x7e,     // .XXXXXX.
    0x40,     // .X......
    0x7c,     // .XXXXX..
    0x02,     // ......X.
    0x02,     // ......X.
    0x02,     // ......X.
    0x7c,     // .XXXXX..
    0x00,     // ........
    0x00      // ........
};

