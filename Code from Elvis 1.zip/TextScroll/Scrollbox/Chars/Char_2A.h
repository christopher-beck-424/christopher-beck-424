/* Char_2A.h - '*' Character
 *
 * D Provine, 20 Mar 2012
 */

const byte Char_2A[10] = {
    0x00,     //.........
    0x2A,     // ..X.X.X.
    0x1C,     // ...XXX..
    0x7F,     // .XXXXXXX
    0x1C,     // ...XXX..
    0x2A,     // ..X.X.X.
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
};

