/* Char_4F.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 */

const byte Char_4F[10] = {
    0x00,     // ........
    0x3c,     // ..XXXX..
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x3c,     // ..XXXX..
    0x00,     // ........
    0x00      // ........
};

