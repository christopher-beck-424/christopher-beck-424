/* Char_67.h - 'g' Character
 *
 * D Provine, 20 Mar 2012
 * J Moore, 21 Apr 2021
 */

const byte Char_67[10] = {
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
    0x3D,     // ..xxxx.x
    0x43,     // .x....xx
    0x41,     // .x.....x
    0x43,     // .x....xx
    0x3D,     // ..xxxx.x
    0x01,     // .......x
    0x3E      // ..xxxxx.
};

