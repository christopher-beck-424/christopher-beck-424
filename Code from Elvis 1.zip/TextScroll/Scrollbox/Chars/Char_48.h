/* Char_48.h - Capital " H " character
 *
 *
 * D Provine, 20 Mar 2012
 * E Jackson, 21 Apr 2021
 */

const byte Char_48[10] = {
    0x00,     // ........
    0x42,     // xx....xx
    0x42,     // xx....xx
    0x42,     // xx....xx
    0x7E,     // xxxxxxxx
    0x42,     // xx....xx
    0x42,     // xx....xx
    0x42,     // xx....xx
    0x00,     // ........
    0x00      // ........
};


