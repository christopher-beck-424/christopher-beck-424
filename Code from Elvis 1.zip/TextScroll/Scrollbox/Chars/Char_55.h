/* Char_55.h - Upper-case 'U' Character
 *
 * S Colbacchini, 22 April 2021
 * D Provine, 20 Mar 2012
 */

const byte Char_55[10] = {
    0x00,     // ........
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x3c,     // ..xxxx..
    0x00,     // ........
    0x00      // ........
};

