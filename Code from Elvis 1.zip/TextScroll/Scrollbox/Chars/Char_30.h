/* Char_30.h - ZERO Character
 *
 * D Provine, 20 Mar 2012
 * S Lekko, 21 Apr 2021
 */

const byte Char_30[10] = {
    0x00,     // ........
    0x3C,     // ..xxxx..
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x5A,     // .x.x..x.
    0x5A,     // .x....x.
    0x42,     // .x....x.
    0x42,     // ..xxxx..
    0x3C,     // ........
    0x00      // ........
};

