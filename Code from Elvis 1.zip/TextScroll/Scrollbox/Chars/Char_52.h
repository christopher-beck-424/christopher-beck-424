/* Char_52.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 * Monica Torres 21 April 2021
 */

const byte Char_52[10] = {
    0x00,     // ........
    0x7C,     // .xxxxx..
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x7C,     // .xxxxx..
    0x44,     // .x...x..
    0x42,     // .x....x.
    0x41,     // .x.....x
    0x00,      // ........
};

