/* Char_47.h - Capital Letter 'G' Character
 *
 * D Provine, 20 Mar 2012
 *
 * Brian Kim, 22 Apr 2021
 */

const byte Char_47[10] = {
    0x00,     // ........
    0x3e,     // ..XXXXX.
    0x61,     // .XX....X
    0x40,     // .X......
    0x40,     // .X......
    0x47,     // .X...XXX
    0x61,     // .XX....X
    0x3e,     // ..XXXXX.
    0x00,     // ........
    0x00      // ........
};

