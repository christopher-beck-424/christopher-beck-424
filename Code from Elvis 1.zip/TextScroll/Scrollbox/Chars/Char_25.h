/* Char_25.h - NAME_OF_CHARACTER Character
 *
 * V Corradetti, 22 April 2021
 */

const byte Char_25[10] = {
    0x00,     // ........
    0x39,     // ..xxx..x
    0x46,     // .x...xx.
    0x3c,     // ..xxxx..
    0x08,     // ....x...
    0x1e,     // ...xxxx.
    0x31,     // ..xx...x
    0x4e,     // .x..xxx.
    0x00,     // ........
    0x00      // ........
};

