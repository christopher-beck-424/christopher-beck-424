/* Char_38.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 * Monica Torres 21 April 2021
 */

const byte Char_38[10] = {
    0x3C,     // ..xxxx..
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x32,     // ..xxxx..
    0x3C,     // .x....x.
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x42,     // ..xxxx..
    0x3C,      // ........
};

