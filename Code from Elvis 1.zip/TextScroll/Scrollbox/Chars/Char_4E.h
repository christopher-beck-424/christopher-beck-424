/* Char_4E.h - N Character
 *
 * D Provine, 20 Mar 2012
 * M Packi, 21 Apr 2021
 */

const byte Char_4E[10] = {
    0x00,     // ........
    0x61,     // .XX....X
    0x51,     // .X.X...X
    0x51,     // .X.X...X
    0x49,     // .X..X..X
    0x45,     // .X...X.X
    0x45,     // .X...X.X
    0x43,     // .X....XX
    0x00,     // ........
    0x00      // ........
};

