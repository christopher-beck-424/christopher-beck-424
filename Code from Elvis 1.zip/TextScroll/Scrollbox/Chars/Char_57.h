/* Char_57.h - NAME_OF_CHARACTER Character
 *
 * V Corradetti, 22 April 2021
 */

const byte Char_57[10] = {
    0x00,     // ........
    0x41,     // .x.....x
    0x41,     // .x.....x
    0x41,     // .x.....x
    0x49,     // .x..x..x
    0x49,     // .x..x..x
    0x55,     // .x.x.x.x
    0x22,     // ..x...x.
    0x00,     // ........
    0x00      // ........
};

