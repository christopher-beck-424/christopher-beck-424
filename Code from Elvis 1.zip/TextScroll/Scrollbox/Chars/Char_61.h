/* Char_61.h - Lowercase Letter 'a' Character
 *
 * D Provine, 20 Mar 2012
 *
 * Brian Kim, 22 Apr 2021
 */

const byte Char_61[10] = {
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
    0x18,     // ...xx...
    0x24,     // ..x..x..
    0x24,     // ..x..x..
    0x26,     // ..x..xx.
    0x1A,     // ...xx.x.
    0x00,     // ........
    0x00      // ........
};

