/* Char_24.h - $ Character
 *
 * D Provine, 20 Mar 2012
 * P Conway, 22 Apr 2021
 */

const byte Char_24[10] = {
    0x00,     // ........
    0x3c,     // ..XXXX..
    0x4a,     // .X..X.X.
    0x48,     // .X..X...
    0x3c,     // ..XXXX..
    0x0a,     // ....X.X.
    0x4a,     // .X..X.X.
    0x3c,     // ..XXXX..
    0x00,     // ........
    0x00      // ........
};

