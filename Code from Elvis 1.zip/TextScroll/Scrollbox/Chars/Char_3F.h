/* Char_3F.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 * K Blake,   22 April 2021
 */

const byte Char_3F[10] = {
    0x3E,     // ..XXXXX.
    0x63,     // .XX...XX
    0x63,     // .XX...XX
    0x06,     // .....XX.
    0x0C,     // ....XX..
    0x18,     // ...XX...
    0x18,     // ...XX...
    0x18,     // ...XX...
    0x00,     // ........
    0x18      // ...XX...
};

