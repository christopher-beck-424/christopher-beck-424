/* Char_29.h - Close Parenthesis ')' Character
 *
 * D Provine, 20 Mar 2012
 * J Gregory, 21 Apr 2021
 */

const byte Char_29[10] = {
    0x08,     // ....X...
    0x04,     // .....X..
    0x02,     // ......X.
    0x02,     // ......X.
    0x02,     // ......X.
    0x02,     // ......X.
    0x04,     // .....X..
    0x08,     // ....X...
    0x00,     // ........
    0x00      // ........
};

