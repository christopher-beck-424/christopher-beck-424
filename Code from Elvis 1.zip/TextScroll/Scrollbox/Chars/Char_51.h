/* Char_51.h - NAME_OF_CHARACTER Character
 *
 * D Provine, 20 Mar 2012
 * Michele Wynn-ROldan, 22 Apr 2021.
 */

const byte Char_51[10] = {
    0x00,     // ........
    0x7E,     // .XXXXXX.
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x42,     // .X....X.
    0x4A,     // .X..X.X.
    0x46,     // .X...XX.
    0x7F,     // .XXXXXXX
    0x00      // ........
};

