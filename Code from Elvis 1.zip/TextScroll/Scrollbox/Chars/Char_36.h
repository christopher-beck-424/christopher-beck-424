/* Char_36.h - Number "6"
 *
 * D Provine, 20 Mar 2012
 * I Styring, 4/22/21
 */

const byte Char_36[10] = {
    0x00,     // ........
    0x1e,     // ...xxxx.
    0x20,     // ..x.....
    0x40,     // .x......
    0x7c,     // .xxxxx..
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x3c,     // ..xxxx..
    0x00,     // ........
    0x00      // ........
};

