/* Char_34.h - 4 Character
 *
 * D Provine, 20 Mar 2012
 * M Packi, 20 Apr 2021
 */

const byte Char_34[10] = {
    0x00,     // ........
    0x03,     // ......XX
    0x05,     // .....X.X
    0x09,     // ....X..X
    0x11,     // ...X...X
    0x3f,     // ..XXXXXX
    0x01,     // .......X
    0x01,     // .......X
    0x00,     // ........
    0x00      // ........
};

