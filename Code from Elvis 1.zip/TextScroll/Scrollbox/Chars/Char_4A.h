/* Char_4A.h - Upper Case Letter for "J"
 *
 * D Provine, 20 Mar 2012
 * I Styring 4/22/21
 */

const byte Char_4A[10] = {
    0x00,     // ........
    0x7e,     // .xxxxxx.
    0x04,     // .....x..
    0x04,     // .....x..
    0x04,     // .....x..
    0x04,     // .....x..
    0x08,     // ....x...
    0x70,     // .xxx....
    0x00,     // ........
    0x00      // ........
};

