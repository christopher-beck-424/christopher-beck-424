/* Char_23.h - Symbol '#' Character
 *
 * S Colbacchini, 22 April 2021
 * D Provine, 20 Mar 2012
 */

const byte Char_23[10] = {
    0x00,     // ........
    0x00,     // ........
    0x24,     // ..x..x..
    0x7e,     // .xxxxxx.
    0x24,     // ..x..x..
    0x7e,     // .xxxxxx.
    0x24,     // ..x..x..
    0x00,     // ........
    0x00,     // ........
    0x00      // ........
};

