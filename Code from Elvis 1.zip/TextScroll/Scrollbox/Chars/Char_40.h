/* Char_40.h - At Character (@)
 *
 * D Provine, 20 Mar 2012
 */

const byte Char_40[10] = {
    0x00,     // ........
    0x3E,     // ..xxxxx.
    0x41,     // .x.....x
    0x5D,     // .x.xxx.x
    0x45,     // .x...x.x
    0x5D,     // .x.xxx.x
    0x55,     // .x.x.x.x
    0x5D,     // .x.xxx.x
    0x3E,     // ..xxxxx.
    0x00      // ........
};

