/* Char_4D.h - 'M' Character
 *
 * D Provine, 20 Mar 2012
 * J Moore, 21 Apr 2021
 */

const byte Char_4D[10] = {
    0x00,     // ........
    0x41,     // .X.....X
    0x63,     // .XX...XX
    0x55,     // .X.X.X.X
    0x49,     // .X..X..X
    0x41,     // .X.....X
    0x41,     // .X.....X
    0x41,     // .X.....X
    0x00,     // ........
    0x00      // ........
};

