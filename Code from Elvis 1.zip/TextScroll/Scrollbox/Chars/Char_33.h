/* Char_33.h - '3' Character
 *
 * D Provine, 20 Mar 2012
 * J Moore, 21 Apr 2021
 */

const byte Char_33[10] = {
    0x00,     // ........
    0x7E,     // .xxxxxx.
    0x01,     // .......X
    0x01,     // .......X
    0x7E,     // .XXXXXX.
    0x01,     // .......X
    0x01,     // .......X
    0x7E,     // .XXXXXX.
    0x00,     // ........
    0x00      // ........
};

