/* Char_77.h - Lower Case 'w' Character
 *
 * D Provine, 20 Mar 2012
 * J Gregory, 21 Apr 2021
 */

const byte Char_77[10] = {
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
    0x41,     // .X.....X
    0x41,     // .X.....X
    0x49,     // .X..X..X
    0x2A,     // ..X.X.X.
    0x14,     // ...X.X..
    0x00,     // ........
    0x00      // ........
};

