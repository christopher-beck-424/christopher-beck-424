/* Char_6E.h - LowerCase 'n' Character
 *
 * D Provine, 20 Mar 2012
 * Monica Torres 21 April 2021
 */

const byte Char_6E[10] = {
    0x00,     // ........
    0x00,     // ........
    0x00,     // ........
    0x5c,     // .x.xxx..
    0x52,     // .xx...x.
    0x00,     // .x....x.
    0x00,     // .x....x.
    0x00,     // .x....x.
    0x00,     // ........
    0x00      // ........
};

