/* Char_26.h - Ampersahd Character
 *
 * D Provine, 20 Mar 2012
 * William Fimple, 21 Mar 2021
 */

const byte Char_26[10] = {
    0x18,     // ...xx...
    0x24,     // ..x..x..
    0x42,     // .x....x.
    0x42,     // .x....x.
    0x2C,     // ..x.xx..
    0x30,     // ..xx....
    0x49,     // .x..x..x
    0x46,     // .x...xx.
    0x39,     // ..xxx..x
    0x00,     // ........
};

