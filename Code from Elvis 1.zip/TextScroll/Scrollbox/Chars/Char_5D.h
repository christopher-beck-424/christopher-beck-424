/* Char_5D.h - Close Bracket ']' Character
 *
 * D Provine, 20 Mar 2012
 * J Gregory, 21 Apr 2021
 */

const byte Char_5D[10] = {
    0x00,     // ........
    0x1f,     // ...XXXXX
    0x01,     // .......X
    0x01,     // .......X
    0x01,     // .......X
    0x01,     // .......X
    0x01,     // .......X
    0x1f,     // ...XXXXX
    0x00,     // ........
    0x00      // ........
};

