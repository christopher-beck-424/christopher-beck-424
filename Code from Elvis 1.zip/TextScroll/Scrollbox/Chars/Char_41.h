/* Char_41.h - ('A') Character
 *
 * D Provine, 20 Mar 2012
 * R Bourne, 22 Apr 2021 
 */

const byte Char_41[10] = {
    0x00,     // ........
    0x3E,     // ..XXXXX.
    0x41,     // .X.....X
    0x41,     // .X.....X
    0x7F,     // .XXXXXXX
    0x41,     // .X.....X
    0x41,     // .X.....X
    0x41,     // .X.....X
    0x00,     // ........
    0x00      // ........
};

