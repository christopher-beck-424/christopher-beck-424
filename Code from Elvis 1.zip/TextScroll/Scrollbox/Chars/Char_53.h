/* Char_53.h - S Character
 *
 * D Provine, 20 Mar 2012
 * Alishba Younas, 22 Apr 2021
 */

const byte Char_53[10] = {
    0x00,     // ........
    0x3c,     // ..XXXX..
    0x22,     // ..X...X.
    0x10,     // ...X....
    0x08,     // ....X...
    0x24,     // ..X..X..
    0x22,     // ..X...X.
    0x1e,     // ...XXXX.
    0x00,     // ........
    0x00      // ........
};

