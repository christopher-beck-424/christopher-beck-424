/* initnum.c - Write Initials And Numbers
 *
 * D Provine, 19 Sep 2016 (updated 19 Feb 2021)
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Maximum number of people we can process.
#define MAXENTRIES 100

// set a buffer size for input
#define BUFSIZE 64

// our structure holds a number and initials
typedef struct {
    char           inits[5];
    unsigned char  num;
} initnum_t;

#define PROGNAMESIZE 16
#define REVISION     1
// structure specifies which revision we used
typedef struct {
    char           progname[PROGNAMESIZE];
    unsigned char  revision;
} filehead;

int main(int argc, char *argv[])
{
    initnum_t   person_data[MAXENTRIES]; // array for data
    FILE       *saveit;                  // pointer to save file
    int         itemsread;               // counter for sscanf()
    int         num = -1;                // person's #
    char        inits[5];                // person's initials
    int         thisone;                 // person's array index
    char        inputline[BUFSIZE];      // line read from input
    filehead    file_info;               // first struct with file info

    // check filename was given
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILENAME\n", argv[0]);
        exit(1);
    }

    thisone = 0;
    // read the next line of input into "inputline"
    while ( num != 0 && fgets(inputline, BUFSIZE, stdin) != NULL ) {

        // scan the number and initials from the line
        itemsread = sscanf(inputline, "%d %4s", &num, inits );

        // if we got valid input, save it to the array
        if (itemsread == 2 && num != 0) {
            person_data[thisone].num = num;
            strcpy(person_data[thisone].inits, inits);

            thisone++;
        }
        if (thisone > MAXENTRIES)
            break;
    }

    // Take filename from command line, open for 'w'riting.
    if ( ( saveit = fopen(argv[1], "w") ) == NULL ) {
        perror(argv[1]);
        exit(1);
    }

    // write file header
    strncpy(file_info.progname, "initnum", PROGNAMESIZE);
    file_info.revision=REVISION;
    if ( fwrite(&file_info, sizeof(filehead), 1, saveit) != 1 ) {
        fprintf(stderr, "Could not write file header to %s\n", argv[1]);
        exit(1);
    }
    
    // write data
    printf("%d\n",
           (int) fwrite(person_data, sizeof(initnum_t), thisone, saveit));

    fclose(saveit);
    return 0;
}
