STRUCTURE READING EXERCISE

The file 'presSQ.dat' was created this way:

    elvis 62> ./initnum presSQ.dat
    1 GW
    4 JM
    9 WHH
    16 AL
    25 WM
    36 LBJ
    0       <- that's the sentinel value which ended input
    6       <- the program saved six records to the file


To see what's in the files, we can use 'od':

  elvis 63> od -Ad -ctx1 presSQ.dat
  0000000   i   n   i   t   n   u   m  \0  \0  \0  \0  \0  \0  \0  \0  \0
           69  6e  69  74  6e  75  6d  00  00  00  00  00  00  00  00  00
  0000016 001   G   W  \0  \0  \0 001   J   M  \0  \0  \0 004   W   H   H
           01  47  57  00  00  00  01  4a  4d  00  00  00  04  57  48  48
  0000032  \0  \0  \t   A   L  \0  \0  \0 020   W   M  \0 334 377 031   L
           00  00  09  41  4c  00  00  00  10  57  4d  00  dc  ff  19  4c
  0000048   B   J  \0  \0   $
           42  4a  00  00  24
  0000053

(The flag '-Ad' means to use decimal numbers in the left-hand column.)

The struct used in 'initnum.c' is 5 initials and one 8-bit integer.

Bytes 0-15 are 'initnum' and then a bunch of null characters.
Byte 16 is the '1' from the file header structure.

Bytes 17-21 are 'GW', a null, two random characters, and then
byte 22 is a '1', because George Washington was President #1.

Bytes 23-27 are 'JM', a null, two random characters, and then
byte 28 is a '4', because James Madison was President #4.




The file 'pres1980.dat' (presidents of the 1980s) was created this way:

    elvis 64> ./initnum2 pres1980.dat
    39 JEC
    40 RWR
    41 GHWB
    0       <- that's the sentinel value again
    3       <- three presidents written to the file

Again, we can use 'od':

  elvis 65> od -Ad -ctx1 pres1980.dat
  0000000   i   n   i   t   n   u   m  \0  \0  \0  \0  \0  \0  \0  \0  \0
           69  6e  69  74  6e  75  6d  00  00  00  00  00  00  00  00  00
  0000016 002   '  \0   J   E   C  \0  \0  \0   (  \0   R   W   R  \0  \0
           02  27  00  4a  45  43  00  00  00  28  00  52  57  52  00  00
  0000032  \0   )  \0   G   H   W   B  \0  \0
           00  29  00  47  48  57  42  00  00
  0000041

The struct used in 'initnum2.c' is a 16-bit integer, followed by 5
initials.

Bytes 0-15 are 'initnum' and then a bunch of null characters.
Byte 16 is the '2' from the file header structure.

Bytes 17-18 are '27 00', little-endian hex representing 0x27, because
Jimmy Carter was president #39.  Bytes 19-23 are 'JEC', a null, and
then a random byte.

Bytes 24-25 are '28 00', little-endian hex representing 0x28, because
Ronald Reagan was president #40.  Bytes 26-30 are 'RWR', a null, and
then a random byte.


Note that President Carter's number is reported as the character
single-quote.  That's because we gave 'od' the -c flag, and so it's
looking up every byte in the ASCII table, since it doesn't know
which bytes are character data and which are not.

 *

Look at the file 'pres21stC.dat' with od.  How was it created?
Identify the binary data from the file.

 *

For the assignment, you have to use 'fread()' to get the first
structure out of the file, and then based on the revision data use
either the structure from 'initnum.c' or 'initnum2.c' to read the
rest of the information.

Here is the output of my program on some input files, with error-
checking:

  elvis 82> ./initread presSQ.dat
  Input File Is Revision 1
  Num  Inits
   1   GW
   4   JM
   9   WHH
   16   AL
   25   WM
   36   LBJ
  End of data.

  elvis 83> ./initread pres1980.dat
  Input File Is Revision 2
  Num  Inits
   39   JEC
   40   RWR
   41   GHWB
  End of data.

  elvis 84> ./initread foobar
  foobar: No such file or directory

  elvis 85> ./initread initread
  File initread is of an unknown type.

  elvis 86> ./initread version3.dat
  version3.dat: Can't process revision 3.

(Note: run 'od' on 'version3.dat' to see what's in it.)
