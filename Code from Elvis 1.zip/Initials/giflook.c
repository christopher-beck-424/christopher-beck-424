/* giflook.c - read a GIF file (we hope!)
 *
 * D Provine and the Spring 2021 Lab Tech Class (Section 3), 29 Mar 2021
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

// https://www.file-recovery.com/gif-signature-format.htm
typedef struct {
    char      gifhead[6];  // 'GIF87a' or 'GIF89a'
    short int width;
    short int height;
} gifinfo;

int main(int argc, char *argv[])
{
    gifinfo  picturedata;
    FILE    *input_stream;
    int      howmany;

    if ( argc < 2 ) {
        fprintf(stderr, "Usage: %s filename\n", argv[0]);
        exit(1);
    }

    if ( ( input_stream = fopen(argv[1], "r") ) == NULL ) {
        perror(argv[1]);
        exit(1);
    }

    if ( (howmany =
          fread(&picturedata, sizeof(gifinfo), 1, input_stream)) != 1 ) {
        if ( feof(input_stream) != 0 ) {
            fprintf(stderr, "EOF on file.\n");
        } else {
            perror(argv[1]);
        }
        exit(1);
    }

    if ( strncmp( picturedata.gifhead, "GIF87a", 6 ) != 0 &&
         strncmp( picturedata.gifhead, "GIF89a", 6 ) != 0    ) {
        fprintf(stderr, "%s: not a GIF file\n", argv[1]);
        exit(1);
    }

    printf("%s : %d x %d\n", argv[1], picturedata.width, picturedata.height);

    return 0;
}
