/* initread.c - Read Information About Multiple People
 *
 * D Provine, 10 Feb 2016
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// copied from 'initnum.c'
typedef struct {
    char           inits[5];
    unsigned char  num;
} initnum_t;

// copied from 'initnum2.c'
typedef struct {
    short int  num;
    char       inits[5];
} initnum_t2;

#define PROGNAMESIZE 16
// head structure specifies which revision was
typedef struct {
    char           progname[PROGNAMESIZE];
    unsigned char  revision;
} filehead;


int main(int argc, char *argv[])
{
    filehead  file_data;
    FILE     *input;
    void      print_data_1(FILE *);
    void      print_data_2(FILE *);
    int       howmany;
    // you may need to declare more variables
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s FILENAME\n", argv[0]);
        exit(1);
    }

    // FILL IN THE REST.
    // Leave the comments below in place, and put the relevant code
    // below each comment as you work.

    // 1: open the file
       
    if((input = fopen(argv[1], "r")) == NULL)
    {
	    perror(argv[1]);
	    exit(1);
       
    // 2: read the header
	if((howmany = fread(&file_data, sizeof(filehead), 1, input)) != -1)
       	{
		if(feof(input)!=0){
			fprint(stderr, "EOF ON FILE %s\n", argv[1]);
	}
		else{
			perror(argv[1]);
		}
    // 3: check to make sure this is the right kind of file
    const char *get_filename_ext(const char *filename) {
    const char *dot = strrchr(filename, '.');
    if(!dot || dot == filename) return "";
    return dot + 1;
}
    // 4: check to make sure the revision is one we know
                 
    // 5: call the right function based on the file header info
    if (file_data.revision == 1) {
        print_data_1(input);
    } else {
        print_data_2(input);
    }

    // 6: close the input stream
    fclose(input);
    return 0;
}


// This function should read data in from the file and print
// it out, like 'person_read.c' from earler in the week.
// But now we have to use a loop, since there's more than one
// record in the file.
void print_data_1 (FILE *input)
{
    initnum_t   person_data; // read data one at a time
    int         howmany;
    printf("Input File Is Revision 1\n");
    printf("Num  Inits\n");
    while ( !feof(input) ) {
        // fill me in
    }
}


// This function should read data in from the file and print
// it out, like 'person_read.c' from earler in the week.
// But now we have to use a loop, since there's more than one
// record in the file.
void print_data_2 (FILE *input)
{
    initnum_t2  person_data; // read data one at a time
    int         howmany;
    
    printf("Input File Is Revision 2\n");
    printf("Num  Inits\n");
    while ( !feof(input) ) {
        // fill me in
    }
}
